Simple logger writen in c++
